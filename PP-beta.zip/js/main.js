//$("body").append("Esto es jquery") 
console.log('mi js');

